export type Contato = {
    telefone?: string;
}; 