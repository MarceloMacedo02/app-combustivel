export type Endereco={
     rua?:string; 
	 numero?:string; 
	 bairro?:string;
	 cep?:string;
}