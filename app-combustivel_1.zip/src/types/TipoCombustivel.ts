export type TipoCombustivel={
    id?: number; 
	nome?: string;
}