export type SampleIdDTO={
    id:number;

}