import { ReactNode } from 'react';

interface DashboardSidebarProps {
  onMobileClose:()=>void
  openMobile:boolean
}

function DashboardSidebar({ onMobileClose,openMobile }: DashboardSidebarProps) {
  return (
    <>
      <h1>DashboardSidebar</h1>
      
    </>
  );
}

export default DashboardSidebar;
