import { ReactNode } from 'react';

interface MainCadastrosProps {
  children?: ReactNode;
}

function MainCadastros({ children }: MainCadastrosProps) {
  return (
    <>
      
    </>
  );
}

export default MainCadastros;
