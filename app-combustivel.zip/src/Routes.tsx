 

  
 
import { Router,Switch ,Route} from 'react-router';
import DashboardLayout from './components/DashboardLayout';
import history from './util/history'; 
const Routes = () => (


    <Router history={history}>
         

                <Switch>
                  
                        <Route path="/" exact>
                        <DashboardLayout /> 
                        </Route>
                        <Route path="/company" exact>
                            
                        </Route>
                 
                </Switch>

             
    </Router>

)

export default Routes;